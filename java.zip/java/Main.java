
public class Main {

	public static void main(String[] args) {
		Plane plane = new Plane();
		SecurityEmployee sec= new SecurityEmployee();
		MaintenanceEmployee maint = new MaintenanceEmployee();
		CleaningEmployee clean = new CleaningEmployee();
		
		plane.process(sec, maint, clean);
		plane.ready_check();
	}
}
