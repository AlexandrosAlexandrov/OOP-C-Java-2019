
public class Employee{
	String name;

	void workOn(PlaneComponent pl){
		pl.process(name);
	}
	void report() {
	}
}
