
public class SecurityEmployee extends Employee {
	
	void report() {
		System.out.println("Security OK!");
	}
	
}