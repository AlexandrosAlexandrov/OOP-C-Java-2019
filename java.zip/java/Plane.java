import java.util.Random;
import java.util.ArrayList;

public class Plane {
	Random rand = new Random();
	
	String description;
	String title;
	int PassengerCapacity = rand.nextInt(10) + 1;								//random number for passengers
	CargoBay cargo;
	EquipmentCompartment[] equip = {
			new EquipmentCompartment(),
			new EquipmentCompartment(),
			new EquipmentCompartment(),
	};
	ArrayList<PassengerCompartment> passengers = new ArrayList<PassengerCompartment>();
	
	
	String get_description() {
		return description;
	}
	
	String get_title() {
		return title;
	}
	
	CargoBay get_cargo() {
		return cargo;
	}
	
	EquipmentCompartment get_equipment(int i) {
		return equip[i];
	}
	
	PassengerCompartment get_passenger(int i) {
		return passengers.get(i);
	}
			
	void ready_check() { 												//ready_checks every component
		cargo.ready_check();	
		for(int i=0; i<3; i++) {
			equip[i].ready_check();
		}
		for(int i=0; i<PassengerCapacity; i++) {
			passengers.get(i).ready_check();
		}
		System.out.println("Plane ready to take off!");
	}
	
	void process(SecurityEmployee emp1, MaintenanceEmployee emp2, CleaningEmployee emp3) {	
		emp1.workOn(cargo);
		for(int i=0; i<3; i++) {
			emp2.workOn(equip[i]);
		}
		for(int i=0; i<PassengerCapacity; i++) {
			emp3.workOn(passengers.get(i));
		}
		
		emp1.report();
		emp2.report();
		emp3.report();
	}
	
	Plane(){
		description = "This is a plane";
		title = "Title of plane";
		cargo = new CargoBay();
		for(int i=0; i<PassengerCapacity; i++) {
			passengers.add(new PassengerCompartment());}			//adds passengers based on the random PassengerCapacity
	}
}
