
public class PrivateCompartment extends PlaneComponent {

	boolean ready_check(){
		System.out.println("Private Compartment OK!");
		return true;
	}

	
	
	PrivateCompartment(){
		
	}
}
