
public class MaintenanceEmployee extends Employee {
	
	void report() {
		System.out.println("Maintenance OK!");
	}
	
}