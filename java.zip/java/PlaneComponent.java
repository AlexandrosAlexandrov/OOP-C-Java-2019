
public class PlaneComponent {
	String description;
	String Employee;
	
	boolean ready_check(){
		if(Employee.isEmpty())
			return true;
		else return false;
	}
	
	void process(String s) {
		Employee = s;
	}
	
	PlaneComponent(){
		description = "This is a Plane Component";
	}
}
