
public class CargoBay extends PrivateCompartment {

	EquipmentCompartment equip = new EquipmentCompartment();
	
	boolean ready_check() {
		System.out.println("Cargo Bay OK!");
		return true;
	}
	
	CargoBay(){
		equip = new EquipmentCompartment();
	}
}
