
public class EquipmentCompartment extends PrivateCompartment {
	
	boolean ready_check() {
		System.out.println("Equipment Compartment OK!");
		return true;
	}
	
	EquipmentCompartment(){
		
	}
}
