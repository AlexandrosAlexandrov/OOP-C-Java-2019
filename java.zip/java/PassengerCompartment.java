
public class PassengerCompartment extends PlaneComponent {
	PassengerCompartment Inner;
	
	boolean ready_check() {
		System.out.println(description);
		System.out.println("Passenger Compartment OK!");
		return true;
	}

	
	
	PassengerCompartment(){
	}
}
