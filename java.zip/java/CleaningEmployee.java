
public class CleaningEmployee extends Employee {
	
	void report() {
		System.out.println("Cleaning OK!");
	}
}
